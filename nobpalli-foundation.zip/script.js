
document.addEventListener('DOMContentLoaded', function() {

    const form = document.querySelector('form');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = form.name.value.trim();
        const email = form.email.value.trim();
        const message = form.message.value.trim();

        if(name === '' || email === '' || message === '') {
            showToast('সকল ফিল্ড পূরণ করুন!', 'error');
            return;
        }

        if(!validateEmail(email)) {
            showToast('সঠিক ইমেইল দিন!', 'error');
            return;
        }

        showToast('ধন্যবাদ! আপনার বার্তা পাঠানো হয়েছে।', 'success');
        form.reset();
    });

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email.toLowerCase());
    }

    const heroBtn = document.querySelector('.hero .btn');
    heroBtn.addEventListener('click', function() {
        showToast('আপনি যোগাযোগ বিভাগে যাচ্ছেন!', 'info');
        document.querySelector('#contact').scrollIntoView({behavior: 'smooth'});
    });

    const header = document.querySelector('header');
    window.addEventListener('scroll', function() {
        if(window.scrollY > 50){
            header.style.background = '#1a252f';
            header.style.transition = '0.3s';
        } else {
            header.style.background = '#2c3e50';
        }
    });

    const services = document.querySelectorAll('.service-box');
    services.forEach(box => {
        box.addEventListener('mouseenter', () => {
            box.style.transform = 'scale(1.05)';
            box.style.boxShadow = '0 10px 20px rgba(0,0,0,0.2)';
        });
        box.addEventListener('mouseleave', () => {
            box.style.transform = 'scale(1)';
            box.style.boxShadow = '0 4px 10px rgba(0,0,0,0.1)';
        });
    });

    function showToast(message, type) {
        const toast = document.createElement('div');
        toast.classList.add('toast', type);
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.classList.add('show');
        }, 100);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => document.body.removeChild(toast), 300);
        }, 3000);
    }

});
